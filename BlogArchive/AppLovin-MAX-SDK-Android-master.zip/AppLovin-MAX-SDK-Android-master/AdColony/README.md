# AdColony Adapter

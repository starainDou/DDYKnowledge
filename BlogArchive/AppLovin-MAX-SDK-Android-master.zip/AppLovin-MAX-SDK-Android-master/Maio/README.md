# Maio Adapter

# MobileFuse Adapter

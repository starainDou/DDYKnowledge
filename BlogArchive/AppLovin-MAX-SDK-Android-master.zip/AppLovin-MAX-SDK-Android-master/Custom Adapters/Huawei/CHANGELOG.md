# Changelog

## 13.4.54.300.2
* Add support for returning the main image asset in `MaxNativeAd` for native ads.

## 13.4.54.300.1
* Fix POM file to point to "ads-prime" artifact id instead of "ads".

## 13.4.54.300.0
* Certified with Huawei SDK 13.4.54.300.

## 13.4.49.301.5
* Update ad display failed error code.

## 13.4.49.301.4
* Remove check for manual native ad assets.

## 13.4.49.301.3
* Fix NPE caused from running ad view logic on background threads by using the UI thread.

## 13.4.49.301.2
* Add support for banners and MRECs.
* Add mapping for errors.

## 13.4.49.301.1
* Support for null `Activity` on init.

## 13.4.49.301.0
* Initial commit.

# Smaato Adapter

# ByteDance Adapter

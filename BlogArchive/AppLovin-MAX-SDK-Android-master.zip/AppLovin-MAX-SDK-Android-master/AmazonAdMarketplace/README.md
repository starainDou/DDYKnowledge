# Amazon Ad Marketplace Adapter

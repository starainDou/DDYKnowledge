# Ogury Presage Adapter

### Warning: This Android adapter must be pushed manually.
To make sure the capitalization and dashes are consistent, this should be pushed manually.

# BidMachine Adapter

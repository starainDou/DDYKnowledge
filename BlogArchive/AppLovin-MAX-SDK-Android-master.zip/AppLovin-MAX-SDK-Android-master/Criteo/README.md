# Criteo Adapter

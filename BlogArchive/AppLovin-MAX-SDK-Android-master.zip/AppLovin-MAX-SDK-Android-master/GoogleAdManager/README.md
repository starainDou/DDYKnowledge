# Google Ad Manager Adapter

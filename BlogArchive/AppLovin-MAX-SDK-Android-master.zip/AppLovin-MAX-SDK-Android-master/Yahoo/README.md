# Verizon Ads Adapter

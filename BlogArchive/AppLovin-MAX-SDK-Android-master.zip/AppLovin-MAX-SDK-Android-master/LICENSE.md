# AppLovin MAX Copyright ©2022 AppLovin

This software is subject to, and made available under, the AppLovin Software Development Kit End User License Agreement (“SDK EULA”), see https://www.applovin.com/eula/.

Your use of the software and accompanying services constitutes your acceptance of such terms. Unless expressly provided otherwise, the software under this license is made available strictly on an “AS IS” BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied. Please review the SDK EULA for details on these and other terms and conditions. 

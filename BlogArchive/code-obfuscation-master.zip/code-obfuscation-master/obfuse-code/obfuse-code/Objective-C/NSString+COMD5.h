//
//  NSString+COMD5.h
//  CodeObfuscation
//
//  Created by hejunqiu on 2017/5/31.
//  Copyright © 2017年 CHE. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (COMD5)

@property (nonatomic, strong, readonly) NSString *md5;

@end

NS_ASSUME_NONNULL_END
